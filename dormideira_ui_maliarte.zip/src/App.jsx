import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

function App() {
  const [acordado, setAcordado] = useState(false);
  const [tema, setTema] = useState('day-theme');
  const [isSending, setIsSending] = useState(false);
  const [pulsoAtivo, setPulsoAtivo] = useState(false);
  const [showFlower, setShowFlower] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const [messages, setMessages] = useState([{ text: 'Olá. O que vamos explorar hoje?', sender: 'ai' }]);
  const [mousePos, setMousePos] = useState({ x: -1000, y: -1000 });
  const [familiaridade, setFamiliaridade] = useState(1.0); // 1.0 (novo) a 0.2 (frequente)

  // 3. Ciclo do Dia (Nictinastia) e Familiaridade
  useEffect(() => {
    const hora = new Date().getHours();
    if (hora >= 18 || hora < 6) setTema('night-theme');
    else setTema('day-theme');
    
    // 5. Familiaridade
    const visitas = parseInt(localStorage.getItem('mta_visits') || '0');
    localStorage.setItem('mta_visits', visitas + 1);
    const novaFamiliaridade = Math.max(0.2, 1.0 - (visitas * 0.15));
    setFamiliaridade(novaFamiliaridade);
  }, []);

  // 1. Tigmonastia (Hover Dinâmico)
  useEffect(() => {
    const handleMouseMove = (e) => {
      setMousePos({ x: e.clientX, y: e.clientY });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const handleWakeUp = () => {
    setAcordado(true);
    triggerPulse();
  };

  const triggerPulse = () => {
    setPulsoAtivo(true);
    setTimeout(() => setPulsoAtivo(false), 600);
  };

  const handleSend = (e) => {
    e.preventDefault();
    if (!inputValue.trim()) return;

    // 4. Impulso de luz pelo Talo
    triggerPulse();
    
    // 2. Escuta ao enviar
    setIsSending(true);
    setMessages([...messages, { text: inputValue, sender: 'user' }]);
    setInputValue('');

    // Simula tempo de rede e IA
    setTimeout(() => {
      setIsSending(false);
      setMessages(prev => [...prev, { text: 'Sinais captados e processados.', sender: 'ai' }]);
      
      // 6. Flor-pompom surge ocasionalmente
      if (Math.random() > 0.3) setShowFlower(true);
    }, 2500);
  };

  // Renderizando a malha de folhas no fundo
  const renderFoliolos = useCallback(() => {
    const folios = [];
    const radius = 180 * familiaridade; // Raio muda de acordo com o conforto da interface

    for (let i = 0; i < 40; i++) {
      const x = (i % 8) * (window.innerWidth / 8) + Math.random() * 50;
      const y = Math.floor(i / 8) * (window.innerHeight / 5) + Math.random() * 50;
      
      const distance = Math.hypot(x - mousePos.x, y - mousePos.y);
      const isFechado = distance < radius;

      folios.push(
        <div
          key={i}
          className={`foliolo ${isFechado ? 'fechado' : ''}`}
          style={{ 
            left: x, 
            top: y,
            transform: `rotate(${Math.random() * 360}deg)`
          }}
        />
      );
    }
    return folios;
  }, [mousePos, familiaridade]);

  return (
    <div className={`app-container ${tema}`}>
      
      {/* 7. Entrada Sensorial */}
      <AnimatePresence>
        {!acordado && (
          <motion.div 
            className="splash-screen"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1.5 }}
            onClick={handleWakeUp}
          >
            <span className="splash-text">toque para acordar</span>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="foliolo-container">
        {acordado && renderFoliolos()}
      </div>

      {acordado && (
        <>
          <div className="talo-container">
            <div className={`pulso-luz ${pulsoAtivo ? 'ativo' : ''}`} />
          </div>

          <div className="chat-area">
            <div className="messages">
              {messages.map((msg, idx) => (
                <motion.div 
                  key={idx}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="message"
                  style={{ alignSelf: msg.sender === 'user' ? 'flex-end' : 'flex-start' }}
                >
                  {msg.text}
                </motion.div>
              ))}
            </div>

            <form onSubmit={handleSend} className={`input-wrapper ${isSending ? 'escutando' : ''}`}>
              <input 
                type="text" 
                className="chat-input"
                placeholder={isSending ? "escutando a rede..." : "insira seu pensamento..."}
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                disabled={isSending}
              />
            </form>
          </div>

          {/* 6. Flor Pompom */}
          <div 
            className={`flor-pompom ${showFlower ? 'visivel' : ''}`} 
            onClick={() => alert('Expandindo dossiê afetivo...')} 
          />
        </>
      )}
    </div>
  );
}

export default App;
