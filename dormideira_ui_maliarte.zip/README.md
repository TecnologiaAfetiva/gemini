# Dormideira UI - Maliarte Tecnologia Afetiva

Protótipo em React da interface sensorial baseada em biologia para o projeto Maliarte.

## Como rodar o projeto localmente:

1. Extraia este arquivo `.zip`.
2. Abra o terminal na pasta raiz (onde está o `package.json`).
3. Instale as dependências:
   `npm install`
4. Inicie o servidor:
   `npm start`

## O que foi implementado e como testar:
1. **Onboarding:** Clique na tela inicial ("toque para acordar").
2. **Tigmonastia:** Mova o mouse pelo fundo. As "folhas" verdes se encolhem (ficam mostarda) ao redor do cursor.
3. **Pulso de Luz:** Digite algo no input e dê Enter. Observe a linha rosa subindo pela lateral esquerda.
4. **Respiração (Escuta):** O input muda o placeholder e reduz de tamanho suavemente até a resposta chegar.
5. **Familiaridade (Habituação):** Recarregue a página algumas vezes. O sistema salva as visitas no LocalStorage e reduz o "medo" das folhas (elas passam a encolher apenas se o mouse chegar bem mais perto).
6. **Flor Pompom:** Ocasionalmente, após a resposta da IA, a flor rosa pulsante aparece no canto inferior direito.
7. **Ciclo Dia/Noite:** A cor do background se adapta automaticamente de acordo com o relógio do seu computador (tema escuro a partir das 18h).
